package com.example.myapy.ui.Investigadores;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class InvestigadoresViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public InvestigadoresViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
package com.example.myapy.models.investigadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapy.R;

import java.util.ArrayList;

public class InvestigatorAdapter extends RecyclerView.Adapter<InvestigatorAdapter.OperadorViewHolder>{

    public ArrayList<Investigator>  listado;

    public InvestigatorAdapter(ArrayList<Investigator> listaOperadores) {
        this.listado = listaOperadores;
    }

    @Override
    public OperadorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.inves_row,parent,false);
        return new OperadorViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OperadorViewHolder holder, int position) {
        holder.bindOperador(listado.get(position));
    }

    @Override
    public int getItemCount() {
        return listado.size();
    }

    public void adicionarOperador(ArrayList<Investigator> listaOperadores) {
        this.listado.addAll(listaOperadores);
        notifyDataSetChanged();
    }

    public class OperadorViewHolder  extends RecyclerView.ViewHolder{
        TextView tvNombre;

        public OperadorViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre =(TextView) itemView.findViewById(R.id.tvinves);

        }
        public void bindOperador(Investigator investigators){
            String dato1 = "";
            dato1 += "1. ID: "+investigators.getId()+"\n";
            dato1 += "2. NOMBRE: "+investigators.getNombre()+"\n";
            dato1 += "3. DESCRIPCCION: "+investigators.getDescripcion()+"\n";
            dato1 += "4. AÑO: "+investigators.getAnno()+"\n";
            dato1 += "5. MODALIDAD: "+investigators.getModalidad()+"\n";
            dato1 += "6. PUBLICO: "+investigators.getPublico()+"\n";
            dato1 += "7. DURACION: "+investigators.getDuracion()+"\n";
            dato1 += "8. FECHA: "+investigators.getFecha()+"\n";
            dato1 += "9. ALCANCE: "+investigators.getAlcance()+"\n";
            dato1 += "10. ASISTENTES: "+investigators.getAsistentes()+"\n";
            tvNombre.setText(dato1);



        }
    }
}
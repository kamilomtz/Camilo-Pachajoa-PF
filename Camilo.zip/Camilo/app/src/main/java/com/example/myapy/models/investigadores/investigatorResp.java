package com.example.myapy.models.investigadores;

import java.util.ArrayList;

public class investigatorResp {
    private ArrayList<Investigator> results = null;

    public ArrayList<Investigator> getResults() {
        return results;
    }

    public void setResults(ArrayList<Investigator> results) {
        this.results = results;
    }
}

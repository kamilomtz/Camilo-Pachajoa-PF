package com.example.myapy.models.mascotas;

import com.example.myapy.models.mascotas.Pet;

import java.util.ArrayList;

public class PetRespuesta {
    private ArrayList<Pet> results = null;

    public ArrayList<Pet> getResults() {
        return results;
    }

    public void setResults(ArrayList<Pet> results) {
        this.results = results;
    }
}

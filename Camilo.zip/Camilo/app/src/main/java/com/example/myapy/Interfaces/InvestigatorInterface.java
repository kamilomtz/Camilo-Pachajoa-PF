package com.example.myapy.Interfaces;

import com.example.myapy.models.investigadores.Investigator;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface InvestigatorInterface {
    @GET("/resource/wqus-wx6y.json")
    Call<ArrayList<Investigator>> getInvestigator();
}

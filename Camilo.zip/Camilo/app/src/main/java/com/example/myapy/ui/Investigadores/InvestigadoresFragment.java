package com.example.myapy.ui.Investigadores;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapy.R;
import com.example.myapy.Interfaces.InvestigatorInterface;
import com.example.myapy.models.investigadores.InvestigatorAdapter;
import com.example.myapy.models.investigadores.Investigator;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Callback;
import retrofit2.Response;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class InvestigadoresFragment extends Fragment {

    private InvestigadoresViewModel galleryViewModel;
    private Retrofit retrofit;
    private RecyclerView recyclerview;
    private ArrayList listaOperadores= new ArrayList<>();
    private InvestigatorAdapter adapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(InvestigadoresViewModel.class);
        View root = inflater.inflate(R.layout.fragment_investigadores, container, false);
        final TextView textView = root.findViewById(R.id.text_gallery);
        galleryViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);

            }
        });

        recyclerview =root.findViewById(R.id.rvoperadores);
        retrofit = new Retrofit.Builder()
                .baseUrl("https://www.datos.gov.co/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        recyclerview.setLayoutManager(llm);
        adapter= new InvestigatorAdapter(listaOperadores);
        recyclerview.setAdapter(adapter);

        DividerItemDecoration itemDecoration = new DividerItemDecoration(recyclerview.getContext(),llm.getOrientation());
        recyclerview.addItemDecoration(itemDecoration);


        obtenerDatos();
        return root;
    }

    private void obtenerDatos(){
        InvestigatorInterface service= retrofit.create(InvestigatorInterface.class);
        Call<ArrayList<Investigator>> operadoresRespuestaCall = service.getInvestigator();
        operadoresRespuestaCall.enqueue(new Callback<ArrayList<Investigator>>() {
            @Override

            public void onResponse(Call<ArrayList<Investigator>> call, Response<ArrayList<Investigator>> response) {
            if(response.isSuccessful()){

                 listaOperadores = response.body();
                 adapter=new InvestigatorAdapter(listaOperadores);
                 recyclerview.setAdapter(adapter);

            }else
            {
                Log.e(TAG, " onResponse: "+response.errorBody());
            }
        }

        @Override
        public void onFailure(Call<ArrayList<Investigator>> call, Throwable t) {
            Log.e(TAG," onFailure: "+t.getMessage());
        }


    });
    }
}
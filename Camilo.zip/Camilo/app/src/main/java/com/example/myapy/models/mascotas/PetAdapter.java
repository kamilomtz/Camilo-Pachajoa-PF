package com.example.myapy.models.mascotas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapy.R;

import java.util.ArrayList;

public class PetAdapter extends RecyclerView.Adapter<PetAdapter.AsociacionViewHolder> {

    public ArrayList<Pet> listado;
    public PetAdapter(ArrayList<Pet> listaOperadores) {
        this.listado = listaOperadores;
    }

    public AsociacionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.pet_row,parent,false);
        return new AsociacionViewHolder(v);    }

    @Override
    public void onBindViewHolder(@NonNull PetAdapter.AsociacionViewHolder holder, int position) {
        holder.bindAsociacion(listado.get(position));
    }

    @Override
    public int getItemCount() {
        return listado.size();
    }
    public void adicionarAsociacion(ArrayList<Pet> listaOperadores) {
        this.listado.addAll(listaOperadores);
        notifyDataSetChanged();
    }
    public class AsociacionViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre;

        public AsociacionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = (TextView) itemView.findViewById(R.id.tvpet);

        }
        public void bindAsociacion(Pet pets) {
            String dato1 = "MASCOTAS"+"\n\n";
            dato1 += "1. Nombre del Propietario:\n -> "+pets.getNombre_del_propietario()+"\n";
            dato1 += "2. Nombre Mascota: "+pets.getNombre_mascota()+"\n";
            dato1 += "3. Raza: "+pets.getRaza()+"\n";
            dato1 += "4. Edad: "+pets.getEdad()+"\n";
            dato1 += "5. Sexo: "+pets.getSexo()+"\n";
            dato1 += "6. Especie: "+pets.getEspecie()+"\n";
            dato1 += "7. Zona: "+pets.getZona()+"\n";

            tvNombre.setText(dato1);

        }
    }
}

package com.example.myapy.models.Tenistas;

import java.util.ArrayList;

public class TenstaRespuesta {
    private ArrayList<ModelTenistas> results = null;

    public ArrayList<ModelTenistas> getResults() {
        return results;
    }

    public void setResults(ArrayList<ModelTenistas> results) {
        this.results = results;
    }
}

package com.example.myapy.Interfaces;

import com.example.myapy.models.mascotas.Pet;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PetInterface {
    @GET("/resource/q2pa-tbcs.json")
    Call<ArrayList<Pet>> getPet();

}

